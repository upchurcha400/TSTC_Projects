﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace AnthonyUpchurchM2C
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
